package bynigeri_HW2;
import javax.swing.JFrame;
public class TetrisView {

	public static void main(String[] args) {
		JFrame frame = new JFrame ();
		frame.setSize(1000, 1000);
		frame.setTitle("CS 203 HW 2");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		TetrisComp s = new TetrisComp();
		s.setTetrimino();
		frame.add(s);
		frame.setVisible(true);
		
	}
	
}
