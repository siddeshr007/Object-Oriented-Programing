package bynigeri_HW2;

import java.awt.Color;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.Random;
import javax.swing.JComponent;
public class TetrisComp extends JComponent{
	
	private int shape;
	private Color mycolor;
	
	public void paintComponent(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		Random x= new Random();
		Random y= new Random();
		
		Integer startX = x.nextInt(750)+36;
		Integer startY = y.nextInt(750)+36;
	// This is straight line shape:
		if(shape==0) {
				Rectangle I = new Rectangle(startX,startY,35,35);
				g2.setColor(mycolor);
				g2.fill(I);
				g2.setColor(Color.black);
				g2.draw(I);
				startX += 35;
				Rectangle I2 = new Rectangle(startX,startY,35,35);
				g2.setColor(mycolor);
				g2.fill(I2);
				g2.setColor(Color.black);
				g2.draw(I2);
				startX += 35;
				Rectangle I3 = new Rectangle(startX,startY,35,35);
				g2.setColor(mycolor);
				g2.fill(I3);
				g2.setColor(Color.black);
				g2.draw(I3);
				startX += 35;
				Rectangle I4 = new Rectangle(startX,startY,35,35);
				g2.setColor(mycolor);
				g2.fill(I4);
				g2.setColor(Color.black);
				g2.draw(I4);		
					}
		// This is L-shape:
		else if(shape==1) {
			Rectangle I = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I);
			g2.setColor(Color.black);
			g2.draw(I);
			startX += 35;
			Rectangle I2 = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I2);
			g2.setColor(Color.black);
			g2.draw(I2);
			startX += 35;
			Rectangle I3 = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I3);
			g2.setColor(Color.black);
			g2.draw(I3);
			startY += 35;
			Rectangle I4 = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I4);
			g2.setColor(Color.black);
			g2.draw(I4);
				}
	
		else if(shape==2) {
			Rectangle I = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I);
			g2.setColor(Color.black);
			g2.draw(I);
			startX += 35;
			Rectangle I2 = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I2);
			g2.setColor(Color.black);
			g2.draw(I2);
			startY += 35;
			startX -= 35;
			Rectangle I3 = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I3);
			g2.setColor(Color.black);
			g2.draw(I3);
			startX += 35;
			Rectangle I4 = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I4);
			g2.setColor(Color.black);
			g2.draw(I4);
				}
		else if(shape==3) {
			Rectangle I = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I);
			g2.setColor(Color.black);
			g2.draw(I);
			startX += 35;
			Rectangle I2 = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I2);
			g2.setColor(Color.black);
			g2.draw(I2);
			startY += 35;
			Rectangle I3 = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I3);
			g2.setColor(Color.black);
			g2.draw(I3);
			startX += 35;
			startY -= 35;
			Rectangle I4 = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I4);
			g2.setColor(Color.black);
			g2.draw(I4);
				}
		else if(shape==4) {
			Rectangle I = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I);
			g2.setColor(Color.black);
			g2.draw(I);
			startX += 35;
			Rectangle I2 = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I2);
			g2.setColor(Color.black);
			g2.draw(I2);
			startY += 35;
			Rectangle I3 = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I3);
			g2.setColor(Color.black);
			g2.draw(I3);
			startX += 35;
			Rectangle I4 = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I4);
			g2.setColor(Color.black);
			g2.draw(I4);
				}
		else if(shape==5) {
			Rectangle I = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I);
			g2.setColor(Color.black);
			g2.draw(I);
			startX += 35;
			Rectangle I2 = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I2);
			g2.setColor(Color.black);
			g2.draw(I2);
			startY -= 35;
			Rectangle I3 = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I3);
			g2.setColor(Color.black);
			g2.draw(I3);
			startX += 35;
			Rectangle I4 = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I4);
			g2.setColor(Color.black);
			g2.draw(I4);
				}
		else if(shape==6) {
			Rectangle I = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I);
			g2.setColor(Color.black);
			g2.draw(I);
			startX -= 35;
			Rectangle I2 = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I2);
			g2.setColor(Color.black);
			g2.draw(I2);
			startX -= 35;
			Rectangle I3 = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I3);
			g2.setColor(Color.black);
			g2.draw(I3);
			startY += 35;
			Rectangle I4 = new Rectangle(startX,startY,35,35);
			g2.setColor(mycolor);
			g2.fill(I4);
			g2.setColor(Color.black);
			g2.draw(I4);
				}
   
	}
	private static final long serialVersionUID = 1L;

	public void setTetrimino() {
		 Random myNum = new Random();
		 Random r = new Random();
		 Random g = new Random();
		 Random b = new Random();
		
		 this.shape = myNum.nextInt(7);
		 this.mycolor = new Color(r.nextInt(256), g.nextInt(256), b.nextInt(256));
		
		
	}

}
