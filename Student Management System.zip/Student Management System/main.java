package bynigeri_HW4;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
public class main {
  public static void main(String[] args) {
    String line = "";
    String splitBy = ",";
    ArrayList<Student> students = new ArrayList<Student>();
    HashMap<String, Integer> advisors = new HashMap <String, Integer>();
    try {
      //parsing a CSV file into BufferedReader class constructor  
      BufferedReader br = new BufferedReader(new FileReader("students_dataset.csv"));
      br.readLine();
      
      while ((line = br.readLine()) != null)
      //returns a Boolean value  
      {
        String[] data = line.split(splitBy);
     
        
        Student student = new Student (data);
        //use comma as separator  
        //System.out.println("Student[First Name=" + student[0] + ", Last Name=" + student[1] + ", Major=" + student[2] + ", Degree=" + student[3] + ", GPA= " + student[4] + ", CreditHours= " + student[5] +", TA= " + student[6] +", Advisor= " + student[7]+ "]");
        if (advisors.containsKey(student.getAdvisor())) {
        	int current = advisors.get(student.getAdvisor());
        	advisors.put(student.getAdvisor(),current+1);
        	
        }
        else {
        	advisors.put(student.getAdvisor(),1);
        	
        }
        students.add(student);
        
      }
      System.out.println("The answer for the first problem is below");
      System.out.println("The names of the advisors are "+ advisors.keySet().toString());
      System.out.println("The total number of advisors is " + advisors.keySet().size());
      
      System.out.println("The answer for the second problem is below");
      for(Student student: students) {
    	  
    	  if (student.getGPA() < 2.75) {
    		  System.out.println(student.toString());
    		  
    	  }
      }
      System.out.println("The answer for the third problem is below");
      int total=0;
      int count = 0;
      for(Student student: students) {
    	  total += student.getCreditHours();
    	  count += 1;
    	  
    	  
      }
      System.out.println("The average number of credit hours is " + total/count);
      System.out.println("The answer for the fourth problem is below");
      double total2 = 0.0;
      int count2 = 0;
      for(Student student: students) {
    	  if (student.getMajor().equals("Computer Science")) {
    		  total2 += student.getGPA();
    		  count2 += 1;
    	  }
      }
      System.out.println("Average GPA for students in Computer Science " + total2/count2);
      System.out.println("The answer for the fifth problem is below");
      ArrayList<String> majors = new ArrayList<String>();
      for(Student student: students) {
    	  if (majors.contains(student.getMajor())) {
    		  continue;
    		  
    	  }
    	  else {
    		  majors.add(student.getMajor());
    		  
    	  }
      }
      for(String major: majors) {
          ArrayList<String> majorAdvisors = new ArrayList<String>();
          for(Student student: students) {
        	  if (student.getMajor().equals(major)) {
        		  if (majorAdvisors.contains(student.getAdvisor())) {
        			  continue;
        			  
        		  }
        		  else {
        			  majorAdvisors.add(student.getAdvisor());
        			  
        		  }
        	  }
          }
          System.out.println(major+" has " + majorAdvisors.size() + " advisors.");
          
          

    	   
      }

    }

    catch(IOException e) {
      e.printStackTrace();
    }
  }
}