package bynigeri_HW4;

public class Student {
	
	private String FirstName;
	private String LastName;
	private String Major;
	private String Degree;
	private double GPA;
	private int CreditHours;
	private String Advisor;
	private String TA;
	
	public Student(String[] values) {
		
		this.FirstName = values[0].trim();
		this.LastName = values[1].trim();
		this.Major = values[2].trim();
		this.Degree = values[3].trim();
		this.GPA = Double.parseDouble(values[4].trim());
		this.CreditHours = Integer.parseInt(values[5].trim());
		this.TA = values[6].trim();
		this.Advisor = values[7].trim();
		}


	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getMajor() {
		return Major;
	}
	public void setMajor(String major) {
		Major = major;
	}
	public String getDegree() {
		return Degree;
	}
	public void setDegree(String degree) {
		Degree = degree;
	}
	public double getGPA() {
		return GPA;
	}
	public void setGPA(double gPA) {
		GPA = gPA;
	}
	public int getCreditHours() {
		return CreditHours;
	}
	public void setCreditHours(int creditHours) {
		CreditHours = creditHours;
	}
	public String getAdvisor() {
		return Advisor;
	}
	public void setAdvisor(String advisor) {
		Advisor = advisor;
	}
	public String getTA() {
		return TA;
	}
	public void setTA(String tA) {
		TA = tA;
	}
	
	@Override public String toString() { 
		return "Student [FirstName=" + FirstName + ",LastName=" + LastName + ",Major=" + Major + ",Degree=" + TA + ",GPA=" + GPA + " CreditHours=" + CreditHours + ", Advisor=" + Advisor + "]";
		
	}

	
}
