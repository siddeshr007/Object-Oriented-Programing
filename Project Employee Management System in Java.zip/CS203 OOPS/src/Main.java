import DAO.Employee;
import Helpers.EmployeeHelper;
import Service.EmployeeService;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String workingDirectory = System.getProperty("user.dir");
        String fileInputPath = workingDirectory+"\\src\\Config\\UabEmployee.txt";
        EmployeeService employeeService = new EmployeeService(fileInputPath);
        Scanner in = new Scanner(System.in);
        while(true) {
            printOptions();
            int option = in.nextInt();
            if (option == 1) {
                addEmployee(in,employeeService);
            } else if (option == 2) {
                deleteEmployee(in,employeeService);
            } else if (option == 3) {
                employeeService.update();
                System.out.println("Successfully updated employee db.");
            } else if (option == 4) {
                employeeService.display();
            } else if (option == 5) {
                System.out.println("Exiting....");
                break;
            }
            else {
                System.out.println("Entered invalid option, please select one of the above options (1 to 5)");
            }
            System.out.println("-------------------------------------------------------------------");
        }
        System.out.println("Exited....");
    }
    private static void printOptions(){
        System.out.println("*********************************************************");
        System.out.println("1. Add Employee");
        System.out.println("2. Delete Employee");
        System.out.println("3. Update DB");
        System.out.println("4. List Employees");
        System.out.println("5. Exit");
        System.out.println("*********************************************************");
        System.out.print("Enter any of the above options : ");
    }
    private static void printAddOptions(){
        System.out.println("E. Hospital Employee");
        System.out.println("D. Doctor");
        System.out.println("N. Nurse");
        System.out.println("A. Administrator");
        System.out.println("S. Surgeon");
        System.out.println("R. Receptionist");
        System.out.println("I. IT Professional");
        System.out.println("J. Janitor");
        System.out.print("Enter employee type from above options (only 1 char) (E/D/N/A/S/R/I/J): ");
    }
    private static void addEmployee(Scanner in, EmployeeService employeeService){
        printAddOptions();
        char empType = Character.toUpperCase(in.next().charAt(0));
        String employeeDetails = empType+"";
        System.out.print("Enter name of the employee name: ");
        String name = in.next();
        System.out.print("Enter blazer id of the employee: ");
        int blazerId = in.nextInt();
        employeeDetails+= " "+name+" "+blazerId;
        if(empType=='D'){
            System.out.print("Enter speciality of the employee: ");
            String speciality = in.next();
            employeeDetails +=" "+ speciality;
        }
        if(empType=='N'){
            System.out.print("Enter no of patients under the employee: ");
            int noOfPatients = in.nextInt();
            employeeDetails += " "+noOfPatients;
        }
        if(empType=='A' || empType=='J' || empType=='R' || empType=='S'){
            System.out.print("Enter department name of the employee: ");
            String dept = in.next();
            employeeDetails +=" "+dept;
        }
        if(empType=='R' || empType=='S' || empType=='j'){
            System.out.print("Does employee performing the action?(Sweeping/Operating/Talking): either (Y/N) ");
            employeeDetails +=" "+Character.toUpperCase(in.next().charAt(0));
        }
        if(empType=='I'){
            System.out.print("Enter team name of the employee: (D-Developers/W-Web/N-Networking): either (D/W/N) ");
            employeeDetails +=" "+Character.toUpperCase(in.next().charAt(0));
        }
        System.out.println("adding -> "+employeeDetails);
        Employee emp = EmployeeHelper.createEmployee(employeeDetails.trim());
        if(emp==null){
            System.out.println("Something went wrong with inputs");
        }else employeeService.add(emp);
    }
    private static void deleteEmployee(Scanner in,EmployeeService employeeService){
        System.out.print("1. Enter name of the employee type: ");
        String name = in.next();
        System.out.print("2. Enter blazer id of the employee: ");
        int blazedId = in.nextInt();
        boolean isDeleted = employeeService.delete(name, blazedId);
        if (isDeleted) System.out.println("Successfully deleted employee.");
        else System.out.println("Failed to deleted employee or no employee exist with given details.");
    }
}