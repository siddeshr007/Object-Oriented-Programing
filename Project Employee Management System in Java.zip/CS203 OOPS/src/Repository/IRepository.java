package Repository;

import java.util.List;

public interface IRepository<T> {
    void add(T model);
    void delete(T model);
    List<T> list();

    void display();
}
