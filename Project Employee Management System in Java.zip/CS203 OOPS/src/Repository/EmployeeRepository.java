package Repository;

import DAO.Employee;

import java.util.List;
import java.util.Optional;

public class EmployeeRepository  extends  Repository<Employee>{

    @Override
    public void display() {
        List<Employee> employees = list();
        System.out.println("Displaying contents of Employee Repository");
        System.out.println(employees);
    }
    public Employee get(String name, Integer blazerId){
        List<Employee> employees = list();
        Optional<Employee> optionalEmployee = employees.stream().filter(emp->emp.getBlazerId().equals(blazerId) && emp.getName().equals(name)).findFirst();
        return optionalEmployee.isPresent()?optionalEmployee.get():null;
    }
}
