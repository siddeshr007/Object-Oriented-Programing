package DAO;

public class Surgeon extends Employee{
    private String department;
    private Character isOperating;
    public Surgeon(){
        setRepresentation('S');setTypeName("Surgeons");
    }
    @Override
    public String toString() {
        return super.toString()+" "+ getDepartment()+" "+isOperating();
    }
    @Override
    public String printDetails() {
        return super.printDetails()+" Department: "+ getDepartment()+" Operating: "+isOperating();
    }
    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public Character isOperating() {
        return isOperating;
    }

    public void setOperating(Character operating) {
        isOperating = operating;
    }
}
