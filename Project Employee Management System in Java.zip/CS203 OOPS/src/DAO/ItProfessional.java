package DAO;

import java.security.InvalidParameterException;
import java.util.Arrays;
import java.util.HashSet;

public class ItProfessional extends Employee{
    private String team;
    public ItProfessional(){
        setRepresentation('I');setTypeName("IT Team");
    }
    @Override
    public String toString() {
        return super.toString()+" "+ getTeam();
    }
    @Override
    public String printDetails() {
        return super.printDetails()+" Team: "+ getTeam();
    }
    public String getTeam() {
        return team;
    }

    public void setTeam(Character team) {
        if(!(new HashSet<Character>(Arrays.asList('D','W','N'))).contains(team)) {
            throw new InvalidParameterException("Team should be either one of the D/W/N");
        }
        if(team=='D') this.team="Developers";
        else if (team=='W') this.team="Web Services";
        else this.team="Networking";
    }
}
