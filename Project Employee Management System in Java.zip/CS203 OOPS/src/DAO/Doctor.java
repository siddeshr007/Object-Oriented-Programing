package DAO;

public class Doctor extends Employee{
    private String speciality;

    public Doctor(){
        setRepresentation('D');setTypeName("Doctors");
    }
    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    @Override
    public String toString() {
        return super.toString()+" "+ getSpeciality();
    }
    @Override
    public String printDetails() {
        return super.printDetails()+" Speciality: "+ getSpeciality();
    }
}
