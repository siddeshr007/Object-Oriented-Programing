package DAO;

public class Receptionist extends Employee{
    private String department;
    private Character isAnswering;
    public Receptionist(){
        setRepresentation('R');setTypeName("Receptionist");
    }

    @Override
    public String toString() {
        return super.toString()+" "+ getDepartment()+" "+isAnswering();
    }
    @Override
    public String printDetails() {
        return super.printDetails()+" Department: "+ getDepartment()+" Answering: "+isAnswering();
    }
    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public Character isAnswering() {
        return isAnswering;
    }

    public void setAnswering(Character answering) {
        isAnswering = answering;
    }
}
