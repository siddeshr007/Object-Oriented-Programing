package DAO;

public class HospitalEmployee extends Employee{
    public HospitalEmployee(){
        setRepresentation('E');setTypeName("Hospital Employees");
    }
}
