package DAO;

public class Employee {
    public Employee(){
        setRepresentation('E');setTypeName("Employees");
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getBlazerId() {
        return blazerId;
    }

    public void setBlazerId(Integer blazerId) {
        this.blazerId = blazerId;
    }

    private String name;
    private Integer blazerId;
    private String typeName;
    private Character representation;

    public Character getRepresentation() {
        return representation;
    }

    protected void setRepresentation(Character representation) {
        this.representation = representation;
    }
    @Override
    public String toString(){
        return  getRepresentation()+" "+getName()+" "+getBlazerId();
    }

    public String printDetails(){
        return  "Name: "+getName()+" BlazerId: "+getBlazerId();
    }

    public String getTypeName() {
        return typeName;
    }

    protected void setTypeName(String typeName) {
        this.typeName = typeName;
    }
}
