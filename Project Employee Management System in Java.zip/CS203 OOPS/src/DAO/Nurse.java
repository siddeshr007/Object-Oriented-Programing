package DAO;

public class Nurse extends Employee{
    private Integer noOfPatients;
    public Nurse(){
        setRepresentation('N');setTypeName("Nurses");
    }
    @Override
    public String toString() {
        return super.toString()+" "+ getNoOfPatients();
    }
    @Override
    public String printDetails() {
        return super.printDetails()+" Number of Patients: "+ getNoOfPatients();
    }
    public Integer getNoOfPatients() {
        return noOfPatients;
    }

    public void setNoOfPatients(Integer noOfPatients) {
        this.noOfPatients = noOfPatients;
    }
}
