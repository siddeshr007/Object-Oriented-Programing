package DAO;

public class Admin extends Employee{

    public Admin(){
        setRepresentation('A');setTypeName("Administrators");
    }
    private String department;


    @Override
    public String toString() {
        return super.toString()+" "+ getDepartment();
    }
    @Override
    public String printDetails() {
        return super.printDetails()+" Department: "+ getDepartment();
    }
    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
}
