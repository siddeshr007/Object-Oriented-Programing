package DAO;

public class Janitor extends Employee{
    private String department;
    private Character isSweeping;
    public Janitor(){
        setRepresentation('J');setTypeName("Janitors");
    }
    @Override
    public String toString() {
        return super.toString()+" "+ getDepartment()+" "+isSweeping();
    }
    @Override
    public String printDetails() {
        return super.printDetails()+" Department: "+ getDepartment()+" Sweeping: "+isSweeping();
    }
    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public Character isSweeping() {
        return isSweeping;
    }

    public void setSweeping(Character sweeping) {
        isSweeping = sweeping;
    }
}
