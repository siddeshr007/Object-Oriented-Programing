package Service;

import DAO.Employee;
import Helpers.EmployeeHelper;
import Helpers.FileHelper;
import Repository.EmployeeRepository;

import java.util.*;
import java.util.stream.Collectors;

public class EmployeeService{
    EmployeeRepository employeeRepository;
    Map<String,HashSet<String>> employeeMap; // cache
    String fileInputPath;
    public  EmployeeService(String filePath){
        employeeRepository = new EmployeeRepository();
        employeeMap = new HashMap<>();
        fileInputPath = filePath;
        initialize(filePath);
    }
    public boolean add(Employee employee){
        Employee employeeOb = get(employee.getName(),employee.getBlazerId());
        if(employeeOb != null) return false;
        employeeRepository.add(employee);
        employeeMap.computeIfAbsent(employee.getTypeName(), k-> new HashSet<>()).add(employee.printDetails());
        return true;
    }
    public Employee get(String name, Integer blazerId){
        Employee employee = employeeRepository.get(name,blazerId);
        return employee;
    }
    public boolean delete(String name, Integer blazerId){
       Employee employee = get(name,blazerId);
       if(employee == null) return false;
       employeeRepository.delete(employee);
       employeeMap.get(employee.getTypeName()).remove(employee.printDetails());
       return true;
    }
    public List<Employee> list(){
        List<Employee> employees = employeeRepository.list();
        return employees;
    }
    public void display(){
        System.out.println("Total Number of employees = "+employeeMap.values().stream().flatMap(Collection::stream).collect(Collectors.toList()).size());
        for(var entry: employeeMap.entrySet()){
            System.out.println(entry.getKey()+": "+entry.getValue().size());
            for(var emp : entry.getValue()){
                System.out.println(emp);
            }
        }
    }
    public void update() {
        List<Employee> emp = list();
        //employeeService.display();
        for (int i = 0; i < emp.size(); i++) {
            if (i == 0) FileHelper.write(fileInputPath, emp.get(i).toString());
            else FileHelper.append(fileInputPath, "\n" + emp.get(i).toString());
        }
    }
    private void initialize(String filePath){
        if(filePath==null || filePath.isEmpty()) return;
        List<String> employeeDetails = FileHelper.readLines(filePath);
        for (String details:employeeDetails) {
            Employee employee = EmployeeHelper.createEmployee(details.trim());
            if(employee==null){
                System.out.println("Unable to create object for this employee "+ details);
            }else {
                System.out.println("adding - "+ details);
                add(employee);
            }
        }
        //System.out.println(employeeMap.values().size()+ " ->" +employeeMap);

    }
}
