package Helpers;
import java.io.*;
import java.util.*;

public class FileHelper {
    public static List<String> readLines(String filePath){
        ArrayList<String> lines = new ArrayList<>();
        File fp = new File(filePath);
        FileReader fr = null;
        try {
            fr = new FileReader(fp);
            BufferedReader br = new BufferedReader(fr);
            String line;
            while((line = br.readLine())!=null)
                lines.add(line);
        }
        catch (FileNotFoundException ex) {
            throw new RuntimeException(ex);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }finally {

            if(fr!=null) {
                try {
                    fr.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return lines;
    }
    public static boolean write(String filePath, String content){
        File file = new File(filePath);

        FileWriter fr = null;
        try {
            fr = new FileWriter(file, false);
            PrintWriter pwOb = new PrintWriter(fr, false);
            pwOb.flush();
            fr.write(content);
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        } finally {
            if(fr!=null) {
                try {
                    fr.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return true;
    }
    public static boolean append(String filePath, String content) {
        File file = new File(filePath);
        FileWriter fr = null;
        try {
            fr = new FileWriter(file, true);
            fr.write(content);
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        } finally {
            if(fr!=null) {
                try {
                    fr.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return true;
    }
}
