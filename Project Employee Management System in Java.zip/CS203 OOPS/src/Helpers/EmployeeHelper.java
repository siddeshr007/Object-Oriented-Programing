package Helpers;

import DAO.*;

public class EmployeeHelper {
    public static Employee createEmployee(String employeeDetails){
        Employee employee = null;
        if(!validateEmployee(employeeDetails)) return null;
        String[] parts = employeeDetails.split(" ");
        Character employeeRepresentation = parts[0].charAt(0);
        String name = parts[1];
        Integer blazerId = Integer.parseInt(parts[2]);
        switch (employeeRepresentation){
            case 'A'-> {
                Admin emp = new Admin();
                emp.setName(name);
                emp.setBlazerId(blazerId);
                emp.setDepartment(parts[3]);
                employee=emp;
                break;
            }
            case 'D'-> {
                Doctor emp = new Doctor();
                emp.setName(name);
                emp.setBlazerId(blazerId);
                emp.setSpeciality(parts[3]);
                employee=emp;
                break;
            }
            case 'E'-> {
                HospitalEmployee emp = new HospitalEmployee();
                emp.setName(name);
                emp.setBlazerId(blazerId);
                employee=emp;
                break;
            }
            case 'N'-> {
                Nurse emp = new Nurse();
                emp.setName(name);
                emp.setBlazerId(blazerId);
                emp.setNoOfPatients(Integer.parseInt(parts[3]));
                employee=emp;
                break;
            }
            case 'I'-> {
                ItProfessional emp = new ItProfessional();
                emp.setName(name);
                emp.setBlazerId(blazerId);
                emp.setTeam(parts[3].charAt(0));
                employee=emp;
                break;
            }
            case 'J'-> {
                Janitor emp = new Janitor();
                emp.setName(name);
                emp.setBlazerId(blazerId);
                emp.setDepartment(parts[3]);
                emp.setSweeping(parts[4].charAt(0));
                employee=emp;
                break;
            }
            case 'S'-> {
                Surgeon emp = new Surgeon();
                emp.setName(name);
                emp.setBlazerId(blazerId);
                emp.setDepartment(parts[3]);
                emp.setOperating(parts[4].charAt(0));
                employee=emp;
                break;
            }
            case 'R'-> {
                Receptionist emp = new Receptionist();
                emp.setName(name);
                emp.setBlazerId(blazerId);
                emp.setDepartment(parts[3]);
                emp.setAnswering(parts[4].charAt(0));
                employee=emp;
                break;
            }
            default -> {
                return null;
            }
        }
        return  employee;
    }

    private static boolean validateEmployee(String employeeDetails) {
        String regex = "^[ADENIJSR]\\s[a-zA-Z0-9]+\\s[0-9]{4}.*";
        if(employeeDetails !=null && employeeDetails.matches(regex)) return true;
        return false;
    }

}
