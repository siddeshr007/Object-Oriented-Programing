package bonushomework;

public class Employee {

    public String empName;
    public String emplastName;
    public String empTitle;
    public String deptId;
    public double empSalary;

    public Employee(String empName, String emplastName, String empTitle, String deptId, double empSalary) {
        this.empName = empName;
        this.emplastName = emplastName;
        this.empTitle = empTitle;
        this.deptId = deptId;
        this.empSalary = empSalary;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEmplastName() {
        return emplastName;
    }

    public void setEmplastName(String emplastName) {
        this.emplastName = emplastName;
    }

    public String getEmpTitle() {
        return empTitle;
    }

    public void setEmpTitle(String empTitle) {
        this.empTitle = empTitle;
    }

    public String getDeptId() {
        return deptId;
    }

    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }

    public double getEmpSalary() {
        return empSalary;
    }

    public void setEmpSalary(double empSalary) {
        this.empSalary = empSalary;
    }

    @Override
    public String toString() {
        return "Employee{" + "empName=" + empName + ", emplastName=" + emplastName + ", empTitle=" + empTitle + ", deptId=" + deptId + ", empSalary=" + empSalary + '}';
    }
    
    
    
}
