package bonushomework;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {

    FileInputStream fis;
    Scanner fileScanner;

    String lineSplits[];
    Employee object;
    ArrayList<Employee> list_Employee;

    ArrayList<Employee> duplicate_Employee;

    public Main() {

        list_Employee = new ArrayList<Employee>();
        try {
            fis = new FileInputStream("company_records.csv");
            fileScanner = new Scanner(fis);
        } catch (Exception ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void budgetOfEachDept() {
        double budget = 0;
        System.out.println("Budget of Each Department");
        
        try {
            for (int i = 0; i <list_Employee.size(); i++) {
               // System.out.println(list_Employee.get(i).getDeptId());

                if (list_Employee.get(i).getDeptId().equals("EXECUTIVE TEAM")) {
                    budget = budget + list_Employee.get(i).getEmpSalary();
                }
            }
            System.out.println("Budget of EXECUTIVE TEAM : " + budget);
            budget = 0;
            
            for (int i = 0; i <list_Employee.size(); i++) {
              //  System.out.println(list_Employee.get(i).getDeptId());

                if (list_Employee.get(i).getDeptId().equals("ENGINEERING")) {
                    budget = budget + list_Employee.get(i).getEmpSalary();
                }
            }
            System.out.println("Budget of Engineering: " + budget);
            budget = 0;
            
             for (int i = 0; i <list_Employee.size(); i++) {
              //  System.out.println(list_Employee.get(i).getDeptId());

                if (list_Employee.get(i).getDeptId().equals("IT")) {
                    budget = budget + list_Employee.get(i).getEmpSalary();
                }
            }
            System.out.println("Budget of IT: " + budget);
            budget = 0;
            
            for (int i = 0; i <list_Employee.size(); i++) {
               // System.out.println(list_Employee.get(i).getDeptId());

                if (list_Employee.get(i).getDeptId().equals("MARKETING")) {
                    budget = budget + list_Employee.get(i).getEmpSalary();
                }
            }
            System.out.println("Budget of MARKETING: " + budget);
            budget = 0;
            
            for (int i = 0; i <list_Employee.size(); i++) {
               // System.out.println(list_Employee.get(i).getDeptId());

                if (list_Employee.get(i).getDeptId().equals("SALES")) {
                    budget = budget + list_Employee.get(i).getEmpSalary();
                }
            }
            System.out.println("Budget of SALES: " + budget);
            budget = 0;
            
            for (int i = 0; i <list_Employee.size(); i++) {
               // System.out.println(list_Employee.get(i).getDeptId());

                if (list_Employee.get(i).getDeptId().equals("ADMIN")) {
                    budget = budget + list_Employee.get(i).getEmpSalary();
                }
            }
            System.out.println("Budget of ADMIN: " + budget);
            budget = 0;
            
            for (int i = 0; i <list_Employee.size(); i++) {
              //  System.out.println(list_Employee.get(i).getDeptId());

                if (list_Employee.get(i).getDeptId().equals("FINANCE")) {
                    budget = budget + list_Employee.get(i).getEmpSalary();
                }
            }
            System.out.println("Budget of FINANCE: " + budget);
            budget = 0;
            
            for (int i = 0; i <list_Employee.size(); i++) {
               // System.out.println(list_Employee.get(i).getDeptId());

                if (list_Employee.get(i).getDeptId().equals("HUMAN RESOURCES")) {
                    budget = budget + list_Employee.get(i).getEmpSalary();
                }
            }
            System.out.println("Budget of HUMAN RESOURCES: " + budget);
            budget = 0;
            
            System.out.println("-----------------------------------------------");
            
        } catch (Exception e) {
                e.printStackTrace();
        }

    }
    
    
    public void companyList(){
        
        ArrayList<String> list = new ArrayList<String>();
        try{
            System.out.println("------------------------------------");
            for (int i = 0; i <list_Employee.size(); i++) {
               
               list.add(list_Employee.get(i).getDeptId());
            }
            
            HashSet<String> hset = new HashSet(list);
            //System.out.println(hset);
            System.out.println("Company List");
            System.out.println("------------------------------------");
            for(String cmp : hset)
                System.out.println(cmp);
            System.out.println("------------------------------------");
            System.out.println("Total Companies are: "+hset.size());
            System.out.println("------------------------------------");
        }catch(Exception e){
            
        }
    }
    
    public void empWithMinMaxSal(){
         ArrayList<Double> list = new ArrayList<Double>();
        try{
            System.out.println("------------------------------------");
            for (int i = 0; i <list_Employee.size(); i++) {
               
               list.add(list_Employee.get(i).getEmpSalary());
            }
            
            double maxSal = Collections.max(list);
            double minSal = Collections.min(list);
            
            
            
            System.out.println("Employee with highest Salary");
            System.out.println("------------------------------------");
            
            for (int i = 0; i <list_Employee.size(); i++) {
               
               if(list_Employee.get(i).getEmpSalary()==maxSal){
                   System.out.println("Employee Name"+list_Employee.get(i).getEmpName());
                   System.out.println("Employee Last Name"+list_Employee.get(i).getEmplastName());
                   System.out.println("Employee Department"+list_Employee.get(i).getDeptId());
                   System.out.println("Employee Title"+list_Employee.get(i).getEmpTitle());
                   System.out.println("Employee Salary"+list_Employee.get(i).getEmpSalary());
               }
            }
            System.out.println("------------------------------------");
            
            System.out.println("Employee with Minimum Salary");
            System.out.println("------------------------------------");
            
            for (int i = 0; i <list_Employee.size(); i++) {
               
               if(list_Employee.get(i).getEmpSalary()==minSal){
                   System.out.println("Employee Name"+list_Employee.get(i).getEmpName());
                   System.out.println("Employee Last Name"+list_Employee.get(i).getEmplastName());
                   System.out.println("Employee Department"+list_Employee.get(i).getDeptId());
                   System.out.println("Employee Title"+list_Employee.get(i).getEmpTitle());
                   System.out.println("Employee Salary"+list_Employee.get(i).getEmpSalary());
               }
            }
            
            
            
        }catch(Exception e){
            
        }
    }

    public void readFile() {

        try {
            while (fileScanner.hasNextLine()) {

                lineSplits = fileScanner.nextLine().split(",");

//                System.out.println(lineSplits[0]);
//                System.out.println(lineSplits[1]);
//                System.out.println(lineSplits[2]);
//                System.out.println(lineSplits[3]);
//                System.out.println(lineSplits[4]);

                if (lineSplits[4].equals("Salary")) {
//                    System.out.println("First Line Rejected");
                } else {
                    object = new Employee(lineSplits[0], lineSplits[1], lineSplits[2], lineSplits[3], Double.parseDouble(lineSplits[4]));
                    list_Employee.add(object);

                }

            }

//            System.out.println(list_Employee);
            duplicate_Employee = list_Employee;
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void main(String args[]) {
        Main main = new Main();
        main.readFile();
        main.budgetOfEachDept();
        main.companyList();
        main.empWithMinMaxSal();
    }

}
