package bynigeri_HW2;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Polygon;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class JavaGraphicsTest1 extends JPanel {

    int frameWidth = 300;
    int frameHeight = 300;
    int x, y, h, w;
    int square;
    int rect;
    int d;

    int xx[];
    int yy[];

    Random r;
    String shapes[] = {"Sqare", "Circle", "Rectangle", "Equilateral Triangle", "Regular Pentagon"};

    public void paint(Graphics g) {
        switch (getOption()) {
            case 0:
                getSquare();
                g.setColor(getColor());
                g.drawRect(x, y, square, square);
                break;
            case 1:
                getCircle();
                g.setColor(getColor());
                g.drawOval(x, x, d, d);
                break;
            case 2:
                getRect();
                g.setColor(getColor());
                g.drawRect(x, y, rect * 2, rect);
                break;
            case 3:
                getEquiTriangle();
                g.setColor(getColor());
                g.drawPolygon(xx, yy, 3);
                break;
            case 4:
                g.setColor(getColor());
                int xValues[] = {r.nextInt(50), r.nextInt(50), r.nextInt(50), r.nextInt(50), r.nextInt(50), r.nextInt(50)};
                int yValues[] = {r.nextInt(80), r.nextInt(80), r.nextInt(80), r.nextInt(80), r.nextInt(80), r.nextInt(80)};
                Polygon polygon1 = new Polygon(xValues, yValues, 6);
                g.drawPolygon(polygon1);

                break;

        }
    }

    public JavaGraphicsTest1() {

        r = new Random();
    }

    public int getOption() {
        int num = r.nextInt(5);
        System.out.println(shapes[num]);
        System.out.println(num);

        return num;
    }

    public void getRect() {
        x = r.nextInt(10);
        y = r.nextInt(10);
        rect = r.nextInt(frameWidth - 15);

    }

    public Color getColor() {
        Color c = new Color(r.nextInt(255), r.nextInt(255), r.nextInt(255));
        return c;
    }

    public void getCircle() {
        x = r.nextInt(10);
        y = r.nextInt(10);
        d = r.nextInt(frameWidth - 15);
    }

    public void getEquiTriangle() {

        int a = r.nextInt(100);

        int x1[] = {a, a + a, 0};
        int y1[] = {0, a + a, a + a};
        xx = x1;
        yy = y1;
    }

    public void getSquare() {
        x = r.nextInt(10);
        y = r.nextInt(10);
        square = r.nextInt(frameWidth - 15);

    }

    public void startApp() {

    }

    public static void main(String[] args) {
        JavaGraphicsTest jgt = new JavaGraphicsTest();
        JFrame jfrm = new JFrame("Java Graphics Tets");
        jfrm.getContentPane().add(jgt);
        jfrm.setSize(jgt.frameWidth, jgt.frameHeight);
        jfrm.setVisible(true);
        jfrm.setResizable(false);
        jfrm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}