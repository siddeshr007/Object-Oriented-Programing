package UABHospital;

public class HospitalEmployee {

	protected String empRole;
	protected String empName;
	protected String empBlazerId;

	public HospitalEmployee() {

	}

	public HospitalEmployee(String empRole, String empName, String empBlazerId) {
		this.setEmpRole(empRole);
		this.setEmpName(empName);
		this.setEmpBlazerId(empBlazerId);
	}

	public String getEmpRole() {
		return empRole;
	}

	public void setEmpRole(String empRole) {
		this.empRole = empRole;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpBlazerId() {
		return empBlazerId;
	}

	public void setEmpBlazerId(String empBlazerId) {
		this.empBlazerId = empBlazerId;
	}

	public String toString() {
		String msg = "Name:  " + empName + "\tBlazer ID:"
				+ empBlazerId + "";
		return msg;
	}
}
