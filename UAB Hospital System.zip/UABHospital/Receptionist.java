package UABHospital;


public class Receptionist extends HospitalEmployee{
	
	private String department, answering;

	public Receptionist(String role, String name, String blazerId, String department, String answering){
		super(role, name, blazerId);
		this.setDepartment(department);
		this.setAnswering(answering);
	}
	
	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getAnswering() {
		return answering;
	}

	public void setAnswering(String answering) {
		this.answering = answering;
	}
	
	public String toString(){
		String msg  = "Name:"+empName+"\tBlazer Id: "+empBlazerId+"\rDepartment : "+department+"\tAnwering : "+answering;
		return msg;
	}
}
