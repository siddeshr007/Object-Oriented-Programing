package UABHospital;

public class Nurse extends HospitalEmployee {

	private String num_Patients;

	public Nurse(String role, String name, String blazerId, String num_Patients) {
		super(role, name, blazerId);
		this.setNum_Patients(num_Patients);
	}

	public String getNum_Patients() {
		return num_Patients;
	}

	public void setNum_Patients(String num_Patients) {
		this.num_Patients = num_Patients;
	}

	public String toString() {
		String msg = "Name :" + empName + "\tBlazer ID :" + empBlazerId
				+ "\tNumber of Patients : " + num_Patients;
		return msg;
	}
}
