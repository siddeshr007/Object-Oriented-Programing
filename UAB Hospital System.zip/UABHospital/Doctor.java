package UABHospital;


public class Doctor extends HospitalEmployee{
	
	private String department;

	public Doctor(String role,String name, String blazerId, String department){
		super(role, name, blazerId);
		this.setDepartment(department);
	}
	
	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}
	public String toString(){
		String msg = "Name :"+empName+"\tBlazer ID: "+empBlazerId+"\tDepartment :"+department;
		return msg;
	}
}