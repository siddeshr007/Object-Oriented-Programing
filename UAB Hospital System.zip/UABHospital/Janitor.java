package UABHospital;

public class Janitor extends HospitalEmployee {

	private String department, sweeping;

	public Janitor(String role, String name, String blazerId,
			String department, String sweeping) {
		super(role, name, blazerId);
		this.setDepartment(department);
		this.setSweeping(sweeping);
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getSweeping() {
		return sweeping;
	}

	public void setSweeping(String sweeping) {
		this.sweeping = sweeping;
	}

	public String toString() {
		String msg = "Name: " + empName + "\tBlazer Id" + empBlazerId
				+ "\tDepartment: " + department + "\tSweeping : " + sweeping;
		return msg;
	}

}
