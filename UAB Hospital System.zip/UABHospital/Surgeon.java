package UABHospital;

public class Surgeon extends HospitalEmployee {

	private String department, operating;

	public Surgeon(String role, String name, String blazerId,
			String department, String operating) {
		super(role, name, blazerId);
		this.setDepartment(department);
		this.setOperating(operating);
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getOperating() {
		return operating;
	}

	public void setOperating(String operating) {
		this.operating = operating;
	}

	public String toString() {
		String msg = "Name:" + empName + "\tBlazer Id: "
				+ empBlazerId + "\rDepartment : " + department
				+ "\tOperating : " + operating;
		return msg;
	}
}
