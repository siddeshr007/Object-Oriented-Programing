package UABHospital;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class StartUp {

	String name, role, blazerId;
	int counter = 0;
	int updateEmp = 0;
	Scanner input;
	HospitalEmployee he[];
	int empCounter[] = { 0, 0, 0, 0, 0, 0, 0, 0 };

	public StartUp() {
		input = new Scanner(System.in);
		he = new HospitalEmployee[100];
	}

	public void welcome() {
		System.out.println("********************************");
		System.out.println(" Welcome to UAB Employee System");
		System.out.println("********************************");
		displayOptions();
	}

	public void displayOptions() {
		System.out.println("********************************");
		System.out.println("Press - 1 To Read Employee Database");
		System.out.println("Press - 2 To Display the Employee List");
		System.out.println("Press - 3 To Add Employee");
		System.out.println("Press - 4 To Delete Employee");
		System.out.println("Press - 5 To Update the Database");
		System.out.println("Press - 6 To Exit");
		System.out.println("********************************");
		handleInputs();
	}

	public void handleInputs() {
		try {
			System.out.print("Enter Your Choice: ");
			int choice = input.nextInt();
			
			switch (choice) {

			case 1:
				this.readDatabase();
				
				break;
			case 2:
				this.displayEmployees();
				
				break;
			case 3:
				this.addEmployees();
				
				break;
			case 4:
				this.deleteEmployee();
				
				break;
			case 5:
				this.updateDatabase();
				break;
			case 6:
				this.exit();
				break;

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void exit(){
		System.out.println("Thanks for Visiting UAB Hospitals Software");
		System.out.println("Bye....");
		System.exit(0);
	}

	public void displayEmployees() {
		System.out.println("********************************");
		System.out.println("\tUAB Employee System");
		System.out.println("********************************");
		System.out
				.println("The UAB Hospital System has the following Employees.");
		System.out.println();
		System.out.println("Total Number of Employees : "+counter);
		System.out.println();
		System.out.println("Hospital Employees " + empCounter[1]);
		for (int i = 0; i < he.length; i++) {
			if (he[i] != null) {
				if (he[i].empRole.equals("E")) {
					System.out.println(he[i]);
				}
			}
		}
		System.out.println("Doctors " + empCounter[2]);
		for (int i = 0; i < he.length; i++) {
			if (he[i] != null) {
				if (he[i].empRole.equals("D")) {
					System.out.println(he[i]);
				}
			}
		}
		System.out.println("Nurses " + empCounter[3]);
		for (int i = 0; i < he.length; i++) {
			if (he[i] != null) {
				if (he[i].empRole.equals("N")) {
					System.out.println(he[i]);
				}
			}
		}
		System.out.println("Administrators " + empCounter[4]);
		for (int i = 0; i < he.length; i++) {
			if (he[i] != null) {
				if (he[i].empRole.equals("A")) {
					System.out.println(he[i]);
				}
			}
		}
		System.out.println("Receptionist " + empCounter[5]);
		for (int i = 0; i < he.length; i++) {
			if (he[i] != null) {
				if (he[i].empRole.equals("R")) {
					System.out.println(he[i]);
				}
			}
		}
		System.out.println("Janitor " + empCounter[6]);
		for (int i = 0; i < he.length; i++) {
			if (he[i] != null) {
				if (he[i].empRole.equals("J")) {
					System.out.println(he[i]);
				}
			}
		}
		System.out.println("Surgeon " + empCounter[7]);
		for (int i = 0; i < he.length; i++) {
			if (he[i] != null) {
				if (he[i].empRole.equals("S")) {
					System.out.println(he[i]);
				}
			}
		}
		displayOptions();
	}

	public void readDatabase() {
		counter =0;
		
		try {
			File f = new File("uabEmployee.txt");
			FileReader reader = new FileReader(f);
			BufferedReader br = new BufferedReader(reader);
			String line;
			String splittedLine[];
			while ((line = br.readLine()) != null) {
				counter++;
				splittedLine = line.split("\\s");
				switch (splittedLine[0]) {

				case "E":
					for (int i = 0; i < he.length; i++) {
						if (he[i] == null) {
							he[i] = new HospitalEmployee(splittedLine[0],
									splittedLine[1], splittedLine[2]);
							break;
						}
					}
					empCounter[1]++;
					break;

				case "D": {

					for (int i = 0; i < he.length; i++) {
						if (he[i] == null) {
							he[i] = new Doctor(splittedLine[0],
									splittedLine[1], splittedLine[2],
									splittedLine[3]);
							break;
						}
					}
					empCounter[2]++;
					break;
				}
				case "N": {

					for (int i = 0; i < he.length; i++) {
						if (he[i] == null) {
							he[i] = new Nurse(splittedLine[0], splittedLine[1],
									splittedLine[2], splittedLine[3]);
							break;
						}
					}
					empCounter[3]++;
					break;
				}
				case "A": {

					for (int i = 0; i < he.length; i++) {
						if (he[i] == null) {
							he[i] = new Administrator(splittedLine[0],
									splittedLine[1], splittedLine[2],
									splittedLine[3]);
							break;
						}
					}
					empCounter[4]++;
					break;
				}
				case "R": {
					for (int i = 0; i < he.length; i++) {
						if (he[i] == null) {
							he[i] = new Receptionist(splittedLine[0],
									splittedLine[1], splittedLine[2],
									splittedLine[3], splittedLine[4]);
							break;
						}
					}
					empCounter[5]++;
					break;
				}
				case "J": {
					for (int i = 0; i < he.length; i++) {
						if (he[i] == null) {
							he[i] = new Janitor(splittedLine[0],
									splittedLine[1], splittedLine[2],
									splittedLine[3], splittedLine[4]);
							break;
						}
					}
					empCounter[6]++;
					break;
				}
				case "S": {
					for (int i = 0; i < he.length; i++) {
						if (he[i] == null) {
							he[i] = new Surgeon(splittedLine[0],
									splittedLine[1], splittedLine[2],
									splittedLine[3], splittedLine[4]);
							break;
						}
					}
					empCounter[7]++;
					break;
				}
				}

				empCounter[0]++;
			}
			System.out.println("Database has been red Successfully");
			System.out.println("Do not read again it leads to duplications");
			this.displayOptions();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void displayAddOptions() {
		System.out.println("*******************************");
		System.out.println("Select Your Choice");
		System.out.println("Press 1: to Add Employee");
		System.out.println("Press 2: to Add Doctor");
		System.out.println("Press 3: to Add Nurse");
		System.out.println("Press 4: to Add Administrator");
		System.out.println("Press 5: to Add Surgeon");
		System.out.println("Press 6: to Add Receptionist");
		System.out.println("Press 7: to Add Janitor");
		System.out.println("*******************************");
	}

	public void employeeInputs() {
		try {
			System.out.print("Enter Role: ");
			role = input.next();
			System.out.print("Enter Name: ");
			name = input.next();
			System.out.print("Enter Blazer ID: ");
			blazerId = input.next();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void addEmployees() {

		int choice;
		try {
			displayAddOptions();
			System.out.print("Enter Your Choice : ");
			choice = input.nextInt();
			switch (choice) {
			case 1:
				employeeInputs();
				for (int i = 0; i < he.length; i++) {
					if (he[i] == null) {
						he[i] = new HospitalEmployee(role, name, blazerId);
						break;
					}
				}
				System.out.println("Employee Added!");
				break;
			case 2:
				employeeInputs();
				System.out.print("Enter Speciality : ");
				String spel = input.next();
				for (int i = 0; i < he.length; i++) {
					if (he[i] == null) {
						he[i] = new Doctor(role, name, blazerId, spel);
						break;
					}
				}
				System.out.println("Doctor Added!");
				break;

			case 3:
				employeeInputs();
				System.out.print("Enter Number of Patients: ");
				String np = input.next();
				for (int i = 0; i < he.length; i++) {
					if (he[i] == null) {
						he[i] = new Nurse(role, name, blazerId, np);
						break;
					}
				}
				System.out.println("Nurse Added!");
				break;

			case 4:
				employeeInputs();
				System.out.print("Enter Speciality : ");
				String dept = input.next();
				for (int i = 0; i < he.length; i++) {
					if (he[i] == null) {
						he[i] = new Administrator(role, name, blazerId, dept);
						break;
					}
				}
				System.out.println("Administrator Added!");
				break;

			case 5:
				employeeInputs();

				System.out.print("Enter Speciality : ");
				String spl = input.next();
				System.out.print("Enter Operating : ");
				String opr = input.next();

				for (int i = 0; i < he.length; i++) {
					if (he[i] == null) {
						he[i] = new Surgeon(role, name, blazerId, spl, opr);
						break;
					}
				}
				System.out.println("Surgeon Added!");
				break;

			case 6:
				System.out.print("Enter Department : ");
				String dep = input.next();
				System.out.print("Enter Answering : ");
				String ans = input.next();

				for (int i = 0; i < he.length; i++) {
					if (he[i] == null) {
						he[i] = new Receptionist(role, name, blazerId, dep, ans);
						break;
					}
				}
				System.out.println("Receptionist Added!");
				break;

			case 7:
				System.out.print("Enter Speciality : ");
				String s = input.next();
				System.out.print("Enter Sweeping : ");
				String sweep = input.next();

				for (int i = 0; i < he.length; i++) {
					if (he[i] == null) {
						he[i] = new Janitor(role, name, blazerId, s, sweep);
						break;
					}
				}
				System.out.println("Janitor Added!");
				break;

			}
			//displayEmployees();
			updateEmp++;
			updateDatabase();
			displayOptions();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deleteEmployee() {
		try {
			System.out.print("Enter Role: ");
			String role = input.next();
			System.out.print("Enter Blazer ID: ");
			String blazerId = input.next();
			System.out.println("Given Text: " + blazerId);
			System.out.println("Size = " + he.length);
			for (int i = 0; i < counter; i++) {

				if (he[i].getEmpBlazerId().equals(blazerId)
						&& he[i].getEmpRole().equals(role)) {
					he[i] = null;
					System.out.println("Employee Deleted Successfully");
					counter--;
					break;
				}
			}

			//displayEmployees();
			displayOptions();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getCause());
		}
		
	}

	public void updateDatabase() {
		try {
			File file = new File("uabEmployee.txt");
			FileOutputStream fout = new FileOutputStream(file);
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fout));

			for (int i = 0; i < (counter+updateEmp); i++) {
				switch (he[i].getEmpRole()) {

				case "E":
					//System.out.println("E");
					bw.write(he[i].getEmpRole() + " " + he[i].getEmpName()
							+ " " + he[i].getEmpBlazerId());
					bw.newLine();
					break;
				case "D":
					//System.out.println("D");
					Doctor d = (Doctor) he[i];
					bw.write(d.getEmpRole() + " " + d.getEmpName() + " "
							+ d.getEmpBlazerId() + " " + d.getDepartment());
					bw.newLine();
					break;
				case "N":
					//System.out.println("N");
					Nurse n = (Nurse) he[i];
					bw.write(n.getEmpRole() + " " + n.getEmpName() + " "
							+ n.getEmpBlazerId() + " " + n.getNum_Patients());
					bw.newLine();
					break;
				case "A":
					//System.out.println("A");
					Administrator a = (Administrator) he[i];
					bw.write(a.getEmpRole() + " " + a.getEmpName() + " "
							+ a.getEmpBlazerId() + " " + a.getDepartment());
					bw.newLine();
					break;
				case "R":
					//System.out.println("R");
					Receptionist r = (Receptionist) he[i];
					bw.write(r.getEmpRole() + " " + r.getEmpName() + " "
							+ r.getEmpBlazerId() + " " + r.getDepartment()
							+ " " + r.getAnswering());
					bw.newLine();
					break;
				case "J":
					//System.out.println("J");
					Janitor j = (Janitor) he[i];
					bw.write(j.getEmpRole() + " " + j.getEmpName() + " "
							+ j.getEmpBlazerId() + " " + j.getDepartment()
							+ " " + j.getSweeping());
					bw.newLine();
					break;
				case "S":
					//System.out.println("S");
					Surgeon s = (Surgeon) he[i];
					bw.write(s.getEmpRole() + " " + s.getEmpName() + " "
							+ s.getEmpBlazerId() + " " + s.getDepartment()
							+ " " + s.getOperating());
					bw.newLine();
					break;

				}
			}
			bw.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		displayOptions();
	}

	public static void main(String args[]) {
		StartUp su = new StartUp();
		su.welcome();
	}
}
